/**
 * Created by bogdanbegovic on 8/29/16.
 */
const Calendar = require("./src/CalendarStrip");
module.exports = Calendar;
